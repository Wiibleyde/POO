#include "qstd.h"
#include "etudiant.h"
using namespace qstd;

int main()
{
    Etudiant e1("Nathan","Bonnell",false,1987);
    try {
        cout << "Moyenne de " << e1.nom() << " : " << e1.moyenne() << "\n";
    } catch (QString exc) {
        cerr << e1.nom() << " : " << exc << ".\n";
    }
    e1.ajouteNote(19);
    e1.ajouteNote(16);
    // cout << "Moyenne de " << e1.nom() << " : " << e1.moyenne() << "\n";
    cout << e1.toString() << "\n";
}
